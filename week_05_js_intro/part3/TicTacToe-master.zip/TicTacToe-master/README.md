#TicTacToe

This is the famous game of TicTacToe that is developed using standard JavaScript.

#####Instructions for Use
1. Download these files to your computer and extract the zip file.
2. Open up js/beginner.js in your text editor.
3. Replace each comment (denoted by the `//` symbol) with the appropriate code.
4. After each direction is followed, open up index.html in your browser and the game should run.